﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplicationAssignment0.Models
{
    public class MovieGenreViewModel
    {
        public List<Movies> Movies { get; set; }
        public string SearchString { get; set; }
    }
}

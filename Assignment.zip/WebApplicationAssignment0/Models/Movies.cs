﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplicationAssignment0.Models
{
    public class Movies
    {
        public int Id { get; set; }

        [Required]
        [StringLength(60, MinimumLength = 3)]
        public string Title { get; set; }
        [Required]
        public Genre Genre { get; set; }
        [Required]
        public DateTime DateTime { get; set; }
        [Required]
        [DataType(DataType.Url)]
        [Display(Name = "Imdb Link")]
        public string ImdbUrl { get; set; }
        [Required]
        [DataType(DataType.ImageUrl)]
        [Display(Name = "Movie Image")]
        public string ImageUrl { get; set; }
    }
}
